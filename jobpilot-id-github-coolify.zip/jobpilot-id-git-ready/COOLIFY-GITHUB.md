# JobPilot ID: deployment from GitHub to Coolify (no FTP)

This folder contains the complete original JobPilot ID starter plus a Git-based
Compose layout. It does **not** contain a browser auto-apply implementation.
It does not send forms for you. SMTP sending is disabled by default.

## Why this version differs from the original starter

- Original `env_file: .env` removed: Coolify variables are set through its UI.
- No repository-relative runtime mounts: non-secret `config/` is copied into the worker image.
- Results and SQLite are persisted in Docker named volumes.
- The user's private CV evidence stays only on the Coolify server at
  `/srv/jobpilot-id/private`, outside GitHub.
- Dashboard is bound to server loopback, port `13030`, **not publicly exposed**.
- The two upstream GitHub projects are cloned at pinned commits during Docker build.

## One-time upload to GitHub

1. Create a **private empty GitHub repository** e.g. `jobpilot-id`.
2. On your own computer unzip the package. In a terminal in this folder:

   ```bash
   git init -b main
   git add .
   git commit -m "Initial JobPilot ID"
   git remote add origin https://github.com/YOUR_USERNAME/jobpilot-id.git
   git push -u origin main
   ```

   If you prefer not to use Git CLI, GitHub's **Add file > Upload files** can
   upload the extracted files and folders; **do not upload the ZIP as one file**.
   If GitHub prompts for authentication, use Git Credential Manager or an
   authenticated GitHub integration (not your GitHub account password).
3. Confirm `.env`, `private/facts.yaml`, `private/profile.yaml`, `data/`, and
   `applications/` are **not** committed. The `.example` files are safe templates.

## Prepare private directory on Coolify's server (over SSH)

   ```bash
   mkdir -p /srv/jobpilot-id/private
   chown 1000:1000 /srv/jobpilot-id/private
   chmod 700 /srv/jobpilot-id/private
   ```

To enable candidate profile scoring and CV generation later, create:
`/srv/jobpilot-id/private/profile.yaml` and `/srv/jobpilot-id/private/facts.yaml`.
Start from the corresponding `.example.yaml` files in GitHub, replacing all
placeholders with confirmed personal information. Example YAML files should
never be treated as a real candidate's facts.

## Coolify: create a new resource

1. In Coolify click **+ New** and select an **Application** backed by GitHub.
   If private, select GitHub App or deploy key with repository access.
2. Select repository and `main` branch.
3. Set **Build strategy: Docker Compose**. Set **Base Directory: /** and
   **Docker Compose Location: /compose.yaml** (or `compose.yaml` if your
   Coolify UI expects paths relative to Base Directory).
4. In **Environment Variables**, add `ANTHROPIC_API_KEY` if you want paid
   matching. Other options: `FIT_MIN=80`, `MAX_AI_EVALUATIONS=20`,
   `SCAN_EVERY_HOURS=24`, and `AUTO_EMAIL=false`.
5. Do **not** add a public dashboard domain unless you have implemented
   authentication and access control.
6. Press Deploy and inspect build and runtime logs.
7. Keep the old failed user-defined Service until you have confirmed the
   new Application works and any data has been migrated.

After `docker compose up`, you can inspect logs in Coolify. The queue is
stored in the `jobpilot_applications` named volume; search data in
`jobpilot_db`. These volumes must be backed up before deleting resources.

For local UI access, forward the server's loopback port from your computer:

   ```bash
   ssh -L 3000:127.0.0.1:13030 root@YOUR_SERVER
   ```

Then open `http://localhost:3000` on your computer. Some Coolify proxy setups
may need networking adjustments; do not expose the unauthenticated board.

## Do not expect upstream GitHub repositories to contain ready-made images

- `fedorchenko-juli/job_search_tool` supplies source code and an existing
  Next.js board, but no Docker image or the JobPilot ID wrapper.
- `Remotivated/job-hunt-skills` supplies CV export tooling and prompts, not
  a complete deployment for our automatic search/sending workflow.
- `narosemena/master-instructional-design` is a proprietary/non-commercial
  methodological reference, deliberately not bundled in this image.

For fully prebuilt images later, CI can build these Dockerfiles and publish to
`ghcr.io/YOUR_USERNAME/jobpilot-pipeline` and `.../jobpilot-dashboard`. Only
then can Coolify use `image: ghcr.io/...` without any build context.

## Before real submissions

The current prototype checks official Greenhouse postings and may prepare
PDFs from verified facts. It cannot complete ATS web forms automatically.
Automated SMTP requires explicit per-vacancy routes and remains disabled.
No live employer submission was performed as part of this package.
